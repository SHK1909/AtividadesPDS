package controle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SomarControler {
//funções 
    public void setStage(Stage stage){
        this.stageSomar = stage;
    }    
    private Stage stageSomar;
    
    @FXML
    private Button btnFechar;

    @FXML
    private Button btnLimpar;

    @FXML
    private Button btnSomar;

    @FXML
    private Label lblNumeroDois;

    @FXML
    private Label lblNumeroUm;

    @FXML
    private Label lblResultado;

    @FXML
    private Label lblSoma;

    @FXML
    private TextField txtNumeroDois;

    @FXML
    private TextField txtNumeroUm;

    @FXML
    void onClickbtnFechar(ActionEvent event) {
        if( stageSomar != null){
           stageSomar.close();
        }
    }
    
    @FXML
    void onClickbtnLimpar(ActionEvent event) {
        txtNumeroUm.setText("");
        txtNumeroUm.requestFocus();
        txtNumeroDois.setText("");
        lblSoma.setText("");
        
    }

    @FXML
    void onClickbtnSomar(ActionEvent event) {
       try{ 
        Double numero1 = Double.valueOf(txtNumeroUm.getText());
        Double numero2 = Double.valueOf(txtNumeroDois.getText());
        
        Double soma = numero1 + numero2;
        
        lblSoma.setText(soma.toString());
       }catch(NumberFormatException n){
           Alert alerta = new Alert(Alert.AlertType.ERROR);
           alerta.setTitle("ERROR");
           alerta.setHeaderText("Caracter Invalido! ");
           alerta.setContentText("Caracter utilizado e invalido para o sistema!");
           alerta.showAndWait();
       }
    }
}
