package controle;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

public class MainController {
//Funções
    public boolean fecharJanela(){
      Alert confirmar = new Alert(Alert.AlertType.CONFIRMATION);
      confirmar.setTitle("Confirmação");
      confirmar.setHeaderText("Deseja fechar o Sistema?");
      confirmar.setContentText("Alterações seram perdidas");
      return confirmar.showAndWait().filter(response -> response == ButtonType.OK).isPresent();
    }
    @FXML
    private Menu manuArquivo;

    @FXML
    private Menu menuAjuda;

    @FXML
    private Menu menuCalculadora;

    @FXML
    private MenuItem menuPesquisa;

    @FXML
    private MenuItem menuSair;

    @FXML
    private MenuItem menuSobre;

    @FXML
    private MenuItem menuSomar;

    @FXML
    void btnPesquisaClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/SegundaTelaAtt.fxml"));
        Parent root= loader.load();
        
       Stage pesq = new Stage();
       
        SegundoControler pc = loader.getController();
        pc.setStage(pesq);
        
        pesq.setOnShown(evento ->{
            pc.agruparElementos();
        });
       
        Scene cena = new Scene(root);
        pesq.setScene(cena);
        pesq.show();
        pesq.setTitle("Pesquisa");
    }

    @FXML
    void btnSairClick(ActionEvent event) {
        if(fecharJanela()){
            System.exit(0);
        }else{
            event.consume();
        }
    }

    @FXML
    void btnSobreClick(ActionEvent event) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("Sobre");
        alerta.setHeaderText("Informações de sistema");
        alerta.setContentText("Sistema desenvolvido na aula de PDS-1 do IFSC");
        alerta.showAndWait();
    }

    @FXML
    void btnSomarClick(ActionEvent event) throws IOException {
              
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/SomarView.fxml"));
        Parent root= loader.load();
        
       Stage somar = new Stage();
       
       SomarControler sc = loader.getController();
       sc.setStage(somar);
       
        Scene cena = new Scene(root);
        somar.setScene(cena);
        somar.show();
        somar.setTitle("Principal");
    } 

}
