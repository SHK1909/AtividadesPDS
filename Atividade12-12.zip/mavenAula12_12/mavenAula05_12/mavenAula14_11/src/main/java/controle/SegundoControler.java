package controle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class SegundoControler {
    void setStage(Stage stage){
        this.stagePesq = stage;
    }
    void agruparElementos(){
        tgLinguagem.getToggles().addAll(RbC, RbJava,RbPython);
        tgSistemaO.getToggles().addAll(tbLinux,tbMac, tbWIndows);
    }
    private Stage stagePesq;
    
    RadioButton botaoLinguagemS;
    ToggleGroup tgLinguagem = new ToggleGroup();
    
    ToggleButton botaoSOs;
    ToggleGroup tgSistemaO = new ToggleGroup();
    
    @FXML
    private CheckBox CbGostadeP;

    @FXML
    private CheckBox CbProgramaTD;

    @FXML
    private RadioButton RbC;

    @FXML
    private RadioButton RbJava;

    @FXML
    private RadioButton RbPython;

    @FXML
    private Button btnSubmeter;

    @FXML
    private ToggleButton tbLinux;

    @FXML
    private ToggleButton tbMac;

    @FXML
    private ToggleButton tbWIndows;

    @FXML
    private TextField txtNomeCOmpleto;

    @FXML
    void onbtnClickSubmeter(ActionEvent event) {
        System.out.println("\n\n");
        if(!txtNomeCOmpleto.getText().isEmpty()){
            System.out.println("Nome completo: "+ txtNomeCOmpleto.getText());
        }
        botaoSOs = (ToggleButton) tgSistemaO.getSelectedToggle();
        System.out.println("Sistema Operacional que utiliza: ");
        if(botaoSOs != null){
            System.out.println(botaoSOs.getText());
        }else{
            System.out.println("Nao selecionado");
        }
        
        botaoLinguagemS = (RadioButton) tgLinguagem.getSelectedToggle();
        System.out.println("Linguagem de programacao preferida: ");
        if(botaoLinguagemS != null){
            System.out.println(botaoLinguagemS.getText());
        }else{
            System.out.println("Nao selecionado");
        }
        
        System.out.println("Programa todo dia? :");
        System.out.println(CbProgramaTD.isSelected() == true ? "Sim" : "Nao");
        
        System.out.println("GOsta de programar? :");
        if(CbGostadeP.isSelected()){
            System.out.println("Sim");
        }else{
            System.out.println("Nao");
        }
    }
    
     @FXML
    void onCLickbtnFechar(ActionEvent event) {
         if( stagePesq != null){
           stagePesq.close();
        }
    }

}
