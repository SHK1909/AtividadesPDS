module principal{
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens controle to javafx.fxml;
    exports principal;
}
